#ifndef _RANDOMSEQ_H_
#define _RANDOMSEQ_H_
#include<stdlib.h>
void Get_Randomseq(long long seq[],int n,int m);
#endif