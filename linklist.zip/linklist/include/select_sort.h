#ifndef _SELECT_SORT_H_
#define _SELECT_SORT_H_
#include<stdio.h>
#include<stdlib.h>
#include "linklist.h"
void Select_Sort(LinkList *list);

#endif